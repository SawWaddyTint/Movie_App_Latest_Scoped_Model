// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'date_vo.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DateVO _$DateVOFromJson(Map<String, dynamic> json) {
  return DateVO(
    maximum: json['maximum'] as String,
    minimum: json['minimum'] as String,
  );
}

Map<String, dynamic> _$DateVOToJson(DateVO instance) => <String, dynamic>{
      'maximum': instance.maximum,
      'minimum': instance.minimum,
    };
