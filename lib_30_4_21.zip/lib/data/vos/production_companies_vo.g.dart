// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'production_companies_vo.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ProductionCompainesVO _$ProductionCompainesVOFromJson(
    Map<String, dynamic> json) {
  return ProductionCompainesVO(
    json['id'] as int,
    json['logo_path'] as String,
    json['name'] as String,
    json['origin_country'] as String,
  );
}

Map<String, dynamic> _$ProductionCompainesVOToJson(
        ProductionCompainesVO instance) =>
    <String, dynamic>{
      'id': instance.id,
      'logo_path': instance.logoPath,
      'name': instance.name,
      'origin_country': instance.originCountry,
    };
